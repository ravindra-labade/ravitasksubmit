from django.urls import path
from .views import create_post, show_post


urlpatterns = [
    path('/add', create_post, name='add'),
    path('/show', show_post, name='show'),
    path('/update/<int:pk>', show_post, name='show'),
    path('/delete/<int:pk>', show_post, name='show'),
]
