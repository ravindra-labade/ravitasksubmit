from django.http import HttpResponse
from django.shortcuts import render
from .models import Post
from .forms import PostForm



def create_post(self, request):
    template_name = 'app1/add.html'
    if request.method == "POST":
        form = PostForm()
        if form.is_valid():
            form.save()
            return HttpResponse('Post added')
    context = {'form': PostForm}
    return render(request, template_name, context)

def show_post(self, request):
    obj = Post.objects.all()
    form = PostForm(obj)
    template_name = 'app1/show.html'
    context = {'form': PostForm}
    return render(request, template_name, context)


