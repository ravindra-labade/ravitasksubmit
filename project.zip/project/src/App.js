import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import add from './Components/add';
import show from './Components/show';
import update from './Components/update';
import deleteFile from './Components/deleteFile';

function App() {
  return (
    <>
    <BrowserRouter>
          <Routes>
                  <Route element={add} path='/add' />
                  <Route element={show} path='/show' />
                  <Route element={update} path='/show' />
                  <Route element={deleteFile} path='/show' />
          </Routes>

    </BrowserRouter>
    </>
  );
}

export default App;
