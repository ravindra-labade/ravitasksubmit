import axios from 'axios'
import React, { useEffect, useState } from 'react'

function show() {
    const [user, setUser] = useState[0]

    async function fethData(data){
        const res = await axios.get('https://127.0.0.1:5000', data)

    }

    useEffect({
        fethData();
    }[])



    }
  return (
   <div>
        <table>
            <thead>
                <tr>
                    <th>id</th>
                    <th>item_name</th>
                    <th>description</th>
                    <th>quantity</th>
                </tr>

            </thead>
            <tbody>
                <tr>
                    <td>

                    </td>
                </tr>
            </tbody>
        </table>
   </div>

  )
}

export default show