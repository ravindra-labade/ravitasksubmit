import axios from 'axios'
import React from 'react'
import { useForm } from 'react-hook-form'


function add() {
    const {register, handleSubmit} = useForm()

    function saveData(data){
        const result = axios.post('https://127.0.0.1:5000', data)
    }


  return (
    
    <div>
    <form onSubmit={handleSubmit(saveData)}>

    <label><ul>item_name</ul></label>
    <input type='text' className='form-control'  />

    <label><ul>description</ul></label>
    <input type='text' className='form-control' />

    <label><ul>quantity</ul></label>
    <input type='number' className='form-control' />

    <label><ul>price</ul></label>
    <input type='number' className='form-control' />



    </form>
    </div>
  )
}

export default add