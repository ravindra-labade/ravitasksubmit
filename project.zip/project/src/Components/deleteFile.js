import React from 'react'

function deleteFile() {
  return (
    <div>deleteFile</div>
  )
}

export default deleteFile